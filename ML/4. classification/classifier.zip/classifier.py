
## 의사결정나무

## iris data

from sklearn.datasets import load_iris

from sklearn.tree import DecisionTreeClassifier

iris = load_iris()

y = iris.target
X = iris.data[:, 2:]

feature_names = iris.feature_names[2:]


tree = DecisionTreeClassifier(criterion = 'entropy', max_depth = 1, random_state = 0)
tree.fit(X, y)


# conda install pydot

import io
import pydot
from IPython.core.display import Image
from sklearn.tree import export_graphviz


def draw_decision_tree(model):
    dot_buf = io.StringIO()
    export_graphviz(model, out_file = dot_buf, feature_names = feature_names)
    graph = pydot.graph_from_dot_data(dot_buf.getvalue())[0]
    image = graph.create_png()
    return Image(image)


draw_decision_tree(tree)


## cancer data

from sklearn.datasets import load_breast_cancer

from sklearn.model_selection import train_test_split

from sklearn.tree import DecisionTreeClassifier

cancer = load_breast_cancer()

print(cancer.DESCR)

print(cancer.data.shape)


X_train, X_test, y_train, y_test = train_test_split(cancer.data, cancer.target, 
                                                    test_size = 0.1,
                                                    stratify = cancer.target, 
                                                    random_state = 42)
feature_names = cancer.feature_names

tree = DecisionTreeClassifier(criterion = 'entropy', max_depth = 1, random_state = 0)

tree.fit(X_train, y_train)

print("Accuracy on training set: {:.3f}".format(tree.score(X_train, y_train)))

print("Accuracy on test set: {:.3f}".format(tree.score(X_test, y_test)))

draw_decision_tree(tree)


## max depth = 2

tree = DecisionTreeClassifier(criterion = 'entropy', max_depth = 2, random_state = 0)

tree.fit(X_train, y_train)

print("Accuracy on training set: {:.3f}".format(tree.score(X_train, y_train)))

print("Accuracy on test set: {:.3f}".format(tree.score(X_test, y_test)))

draw_decision_tree(tree)







### 랜덤포레스트
import numpy as np
import pandas as pd
from sklearn.datasets import load_iris
from sklearn import metrics

from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split


iris = load_iris()

y = iris.target
X = iris.data
feature_names = iris.feature_names


X = pd.DataFrame(data = X, columns = feature_names)
y = pd.DataFrame(data = y, columns = ['type'])


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.3,random_state = 25)

model = RandomForestClassifier()
model.fit(X_train, y_train)
prediction = model.predict(X_test)
100 * metrics.accuracy_score(prediction, y_test)




### XGBoost
from xgboost import XGBClassifier

xgb_model = XGBClassifier()
xgb_model.fit(X_train, y_train)
prediction2 = xgb_model.predict(X_test)
100 * metrics.accuracy_score(prediction2, y_test)



### LightGBM
from lightgbm import LGBMClassifier

lgbm_model = LGBMClassifier()
lgbm_model.fit(X_train, y_train)
prediction3 = lgbm_model.predict(X_test)
100 * metrics.accuracy_score(prediction3, y_test)



## CV 기반 스태킹
pred = np.array([prediction, prediction2, prediction3])
pred.shape

pred = pred.T
pred.shape

lgbm_model.fit(pred, y_test)
final = lgbm_model.predict(pred)
100 * metrics.accuracy_score(y_test, final)











